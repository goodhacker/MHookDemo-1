package ls.Substrace;

public class HookMethod {

	
	
}
