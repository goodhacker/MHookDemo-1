/** Automatically generated file. DO NOT MODIFY */
package ls.mhookdemo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}