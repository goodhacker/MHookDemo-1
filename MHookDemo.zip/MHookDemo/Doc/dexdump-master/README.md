dexdump
=======

Only necessary (i.e., dependant) files for the dexdump tool,
a dialect of objdump, are extracted from Android source tree.
To build the tool, just type:

    $ make

Then, copy the executable file into anywhere you want:

    $ cp a.out /path/to/platform-tools

